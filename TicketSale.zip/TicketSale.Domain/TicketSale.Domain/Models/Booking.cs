﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketSale.Domain.Models
{
    public class Booking
    {
        public int Id { get; set; }
        public int TicketId { get; set; }
        public int BookingStatusId { get; set; }
    }
}
