﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketSale.Domain.Models
{
    public class TransportType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
