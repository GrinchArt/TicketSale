﻿namespace TicketSale.IdentityServer
{
    public class Class1
    {

    }
}
